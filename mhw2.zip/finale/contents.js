const contents = [
    {
      titolo: 'Baby Yoda Lego',
      immagine: 'img/gioco1.jpg',
      descrizione: 'Lego - Star Wars Baby Yoda modellino tratto dalla nuova serie The Mandalorian.'
    },
    {
      titolo: 'Casetta',
      immagine: 'img/gioco2.jpg',
      descrizione: 'Casetta colorata con ingresso e finestre, realizzata con materiali riciclabili.'
    },
    {
      titolo: 'Robot',
      immagine: 'img/gioco3.jpg',
      descrizione: 'NAO è un robot umanoide che si muove, riconosce persone e oggetti, ascolta e parla.'
    },
    {
      titolo: 'Bambolotto',
      immagine: 'img/gioco4.jpg',
      descrizione: 'Bambola Nenuco dormi con me con baby monitor e con lettino a sponda da posizionare vicino al lettino.'
    },
    {
      titolo: 'Barbie- Cucina da Sogno',
      immagine: 'img/gioco5.jpg',
      descrizione: 'Barbie aiuta i piccoli buongustai a divertirsi con la Cucina dei Sogni con luci, suoni, formine di cibi, plastilina in 5 colori e oltre 20 accessori.'
    },
    {
      titolo: 'Laboratorio di Ceramica',
      immagine: 'img/gioco6.jpg',
      descrizione: "CREA MANIA - Pottery Wheel, Laboratorio di Ceramica - Vasaio Elettrico per Modellare l'Argilla."
    },
    {
      titolo: 'Modellino del corpo umano',
      immagine: 'img/gioco7.jpg',
      descrizione: "Modellino corpo umano con parti smontabili per imparare l'anatomia in modo sicuro e intelligente."
    }
    ,
    {
      titolo: 'Laboratorio di Biocosmesi',
      immagine: 'img/gioco8.jpg',
      descrizione: "Clementoni - E' un vero laboratorio scientifico per creare una linea cosmetica bio completa."
    }
  ]

  